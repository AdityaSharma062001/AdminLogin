export default function Updatefess(){


    return<>
   <h1 style={{color:"red"}}>updatefess</h1>






    </>







}