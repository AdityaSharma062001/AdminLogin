import { Component, useState } from "react";
import Menu from './Components/Menu';
import Slider from './Components/Slider';
import About from './Components/About';
import Contact from "./Components/Contact";
import Login from "./Components/Login"
import Course from "./Components/Course"
import Footer from "./Components/Footer";
import { Routes,Route } from "react-router-dom";
import Adminsidebar from "./admin/adminsidebar";
import './App.css'
import Counseller from "./admin/coseller";
import Admincourse from "./admin/admincourse";
import Faculty from "./admin/faculty";
import Updatefess from "./admin/upadatefess";
export default function App (){

      var [tokendata,settokendata]=useState({login:false, token:undefined})

    var funtoken=(data)=>{

              settokendata(data)
    }
    console.log(tokendata.token)

    return <div>
      
   {tokendata.login?<><Adminsidebar token={tokendata.login} funtoken={funtoken}/>
  
  
     <Routes>
      
      <Route path="/counseller" element={<Counseller authtoken={tokendata.token} />}></Route>
      <Route path="/addcourse" element={<Admincourse  authtoken={tokendata.token} />}></Route>
      <Route path="/faculty" element={<Faculty authtoken={tokendata.token}/>}></Route>
      <Route path="/updatefess" element={<Updatefess/>}></Route>
      
     </Routes>

  

   </> :<>

      <Menu/>
      <Routes>
        <Route path="/" element={<Slider/>}/>
        <Route path="/about" element={<About/>}/>
        <Route path="/contact" element={<Contact/>}/>
        <Route path="/login" element={<Login  funtoken={funtoken}/>}/>
        <Route path="/course" element={<Course/>}/>
      </Routes>
      <Footer/>  

     </>}

    

      
      

    </div>
  }